---
Logo: %theme_url%/img/pico-white.svg
Tagline: Pico CMS for Nextcloud in action.
Social:
    - title: Visit us on GitHub
      url: https://github.com/picocms/Pico
      icon: octocat
    - title: Join us on Libera.Chat
      url: https://web.libera.chat/#picocms
      icon: chat
    - title: Help us by creating/collecting bounties and pledging to fundraisers
      url: https://www.bountysource.com/teams/picocms
      icon: dollar
---
