OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "Хуулах",
    "Save" : "Хадгалах",
    "Location" : "Байршил",
    "Access forbidden" : "Хандах эрхгүй",
    "Technical details" : "Техникийн мэдээлэл",
    "Name" : "Нэр",
    "Path" : "Зам",
    "Theme" : "загвар",
    "Created" : "Үүсгэсэн",
    "Actions" : "Үйл ажиллагаа",
    "Address" : "хаяг",
    "Loading…" : "уншиж байна"
},
"nplurals=2; plural=(n != 1);");
