OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "Copïo",
    "Save" : "Cadw",
    "Location" : "Lleoliad",
    "Access forbidden" : "Mynediad wedi'i wahardd",
    "Not found" : "Heb ei ganfod",
    "Name" : "Enw",
    "Actions" : "Gweithredoedd",
    "Address" : "Cyfeiriad",
    "Loading…" : "Yn llwytho…"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
