OC.L10N.register(
    "cms_pico",
    {
    "Save" : "﻿ಉಳಿಸಿ",
    "Access forbidden" : "﻿ಪ್ರವೇಶ ನಿರ್ಬಂಧಿಸಲಾಗಿದೆ",
    "Internal Server Error" : "ಪರಿಚಾರಕ-ಗಣಕದ ಆಂತರಿಕ ದೋಷ",
    "Remote Address: %s" : "ಆಚೆ-ಗಣಕದ ವಿಳಾಸ : %s",
    "Request ID: %s" : "ವಿನಂತಿಯ ಸಂಖ್ಯೆ: %s",
    "Technical details" : "ತಾಂತ್ರಿಕ ವಿವರಗಳು",
    "Code: %s" : "ಸ೦ಕೇತ: %s",
    "Message: %s" : "ಸ೦ದೇಶ: %s",
    "File: %s" : "ಕಡತ: %s",
    "Line: %s" : "ಕೋಂಡಿ: %s",
    "Trace" : "ಕುರುಹು",
    "Name" : "﻿ಹೆಸರು",
    "Address" : "ವಿಳಾಸ"
},
"nplurals=2; plural=(n > 1);");
