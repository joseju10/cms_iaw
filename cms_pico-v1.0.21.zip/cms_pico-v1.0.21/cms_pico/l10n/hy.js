OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "պատճենահանել",
    "Save" : "Պահպանել",
    "Location" : "Տեղակայություն",
    "Type: %s" : "Տիպ. %s",
    "Code: %s" : "Կոդ. %s",
    "Message: %s" : "Նամակ. %s",
    "File: %s" : "Ֆայլ. %s",
    "Line: %s" : "Տող. %s",
    "Trace" : "Հետք",
    "Name" : "Անուն",
    "Address" : "Հասցե"
},
"nplurals=2; plural=(n != 1);");
