OC.L10N.register(
    "cms_pico",
    {
    "Abort" : "Avbryt",
    "Save" : "Lagre",
    "Location" : "Stad",
    "Access forbidden" : "Tilgang forbudt",
    "Name" : "Namn",
    "Path" : "Vei",
    "Created" : "Lagd",
    "Actions" : "Handlingar",
    "Address" : "Adresse"
},
"nplurals=2; plural=(n != 1);");
