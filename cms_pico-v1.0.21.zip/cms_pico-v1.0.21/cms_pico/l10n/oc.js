OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "Copiar",
    "Abort" : "Anullar",
    "Save" : "Salvar",
    "Location" : "Emplaçament",
    "Name" : "Nom",
    "Path" : "Camin",
    "Actions" : "Accions",
    "Address" : "Adreça",
    "Loading…" : "Cargament…"
},
"nplurals=2; plural=(n > 1);");
