OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "ສຳເນົາ",
    "Access forbidden" : "ຫ້າມການເຂົ້າເຖິງ",
    "Back to %s" : "ຫຼັງ%s",
    "Internal Server Error" : "ຄວາມຜິດພາດຂອງ Server ພາຍໃນ",
    "The server was unable to complete your request." : "server ບໍ່ສາມາດສໍາເລັດຄໍາຮ້ອງຂໍຂອງທ່ານ",
    "If this happens again, please send the technical details below to the server administrator." : "ຖ້າຫາກວ່ານີ້ເກີດຂຶ້ນອີກ, ກະລຸນາສົ່ງລາຍລະອຽດທາງດ້ານເຕັກນິກຂ້າງລຸ່ມນີ້ໄປຫາຜູ້ບໍລິຫານ server",
    "Remote Address: %s" : "ທີ່ຢູ່ ໄລຍະໄກ%s ",
    "Request ID: %s" : "ຂໍຮອງ %s",
    "More details can be found in the server log." : "ລາຍລະອຽດເພີ່ມເຕີມສາມາດເບິ່ງໄດ້ໃນ log server.",
    "Technical details" : "ລາຍລະອຽດເຕັກນິກ",
    "Type: %s" : "ພິມ%s",
    "Code: %s" : "ລະຫັດ%s",
    "Message: %s" : "ຂໍ້ຄວາມ %s",
    "File: %s" : "ຟາຍ%s",
    "Line: %s" : "ສາຍ: %s",
    "Trace" : "ຕິດຕາມ",
    "Name" : "ຊື່"
},
"nplurals=1; plural=0;");
