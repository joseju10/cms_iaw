OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "පිටපත්",
    "Abort" : "රෝධනය",
    "Save" : "සුරකින්න",
    "Website not found." : "වියමන අඩවිය හමු නොවීය.",
    "Location" : "ස්ථානය",
    "The name of the website must be longer." : "වියමන අඩවියේ නම දිගු විය යුතුය.",
    "Internal Server Error" : "අභ්‍යන්තර සේවාදායක දෝෂයකි",
    "Remote Address: %s" : "දුරස්ථ ලිපිනය: %s",
    "Technical details" : "තාක්ෂණික විස්තර",
    "Message: %s" : "පණිවිඩය: %s",
    "File: %s" : "ගොනුව: %s",
    "Name" : "නම",
    "Theme" : "තේමාව",
    "Actions" : "ක්‍රියාමාර්ග",
    "Address" : "ලිපිනය",
    "Loading…" : "පූරණය වෙමින්…"
},
"nplurals=2; plural=(n != 1);");
