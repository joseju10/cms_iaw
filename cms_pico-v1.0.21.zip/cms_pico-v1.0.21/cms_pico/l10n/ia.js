OC.L10N.register(
    "cms_pico",
    {
    "Copy" : "Copiar",
    "Save" : "Salveguardar",
    "Location" : "Loco",
    "Remote Address: %s" : "Adresse remote: %s",
    "Request ID: %s" : "ID de requesta: %s",
    "Technical details" : "Detalios technic",
    "Name" : "Nomine",
    "Path" : "Sentiero",
    "Actions" : "Actiones",
    "Address" : "Adresse",
    "Loading…" : "Cargante..."
},
"nplurals=2; plural=(n != 1);");
